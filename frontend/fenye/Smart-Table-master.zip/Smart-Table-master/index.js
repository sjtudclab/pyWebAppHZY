require('./dist/smart-table.js');
module.exports = 'smart-table';